/* a_functions.c  */


#include <stdio.h>

#include "a.h"

void print_A()
{
	printf(A_MESSAGE);
	printf("hej igen");
}

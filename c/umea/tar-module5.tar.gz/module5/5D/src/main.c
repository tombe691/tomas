#include <stdio.h>

#include "main.h"


int main(int argc, char *argv[])
{
	printf("The first four letters of the alphabet:\n");
	print_A();
	print_B();
	print_C();
	print_D();
	return(RETVALUE);
}

#ifndef FILE_A
#define FILE_A
#define nisse

#define A_MESSAGE "A\n"

#endif

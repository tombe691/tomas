/*
    Uppgift1
    Skriva ut a till j med javakod.
    
    Tomas Berggren, tombe691@gmail.com
    2019-02-08
*/

public class Uppgift1
{
    public static void main (String[] args)
    {
	char ch;
	for (ch = 'a'; ch <= 'j'; ch++){
	    System. out. println(ch);
	}
    }
}
